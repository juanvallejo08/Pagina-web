const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public')); // Directorio donde se encuentra el archivo HTML

// Conexión a la base de datos SQLite
const db = new sqlite3.Database('database.db', (err) => {
    if (err) {
      console.error('Error al abrir la base de datos', err.message);
    } else {
      console.log('Conexión exitosa a la base de datos');
    }
  });
  
  // Ruta para registrar un usuario
  app.post('/registrar-usuario', (req, res) => {
    const { nombre, apellido, correo, contrasena } = req.body;
    // Insertar datos en la base de datos
    const sql = `INSERT INTO usuarios (nombre, apellido, correo, contrasena) VALUES (?, ?, ?, ?)`;
    db.run(sql, [nombre, apellido, correo, contrasena], function(err) {
      if (err) {
        return console.error('Error al insertar usuario', err.message);
      }
      console.log(`Usuario insertado con ID: ${this.lastID}`);
      res.send('¡Usuario registrado en la base de datos!');
    });
  });
  
  // Iniciar el servidor
  app.listen(PORT, () => {
    console.log(`Servidor escuchando en el puerto ${PORT}`);
  });
// app.post('/registrar-usuario', (req, res) => {
//   console.log('Datos recibidos:', req.body);
//   res.send('¡Datos recibidos en el servidor!');
// });

// app.listen(PORT, () => {
//   console.log(`Servidor escuchando en el puerto ${PORT}`);
// });